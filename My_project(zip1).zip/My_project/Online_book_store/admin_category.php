<?php

@include 'config.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:login.php');
};

if(isset($_POST['add_category'])){

   $name = mysqli_real_escape_string($con, $_POST['category_name']);

   $select_category_name = mysqli_query($con, "SELECT * FROM `category` WHERE category_name = '$name'") or die('query failed');

   if(mysqli_num_rows($select_category_name) > 0){
      $message[] = 'category name already exist!';
   }else{
      $insert_category = mysqli_query($con, "INSERT INTO `category`(category_name) VALUES('$name')") or die('query failed');
   }

}

if(isset($_GET['delete'])){

   $delete_id = $_GET['delete'];
   mysqli_query($con, "DELETE FROM `category` WHERE category_ID = '$delete_id'") or die('query failed');
   header('location:admin_category.php');

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>category</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/admin_style.css">

</head>
<body>
   
<?php @include 'admin_header.php'; ?>

<section class="add-category">

   <form action="" method="POST" enctype="multipart/form-data">
      <h3>ADD NEW CATEGORY</h3>
      <input type="text" class="box" required placeholder="enter category name" name="category_name">
      <input type="submit" value="add category" name="add_category" class="btn">
   </form>

</section>

<section class="show-category">

   <div class="box-container">

      <?php
         $select_categorys = mysqli_query($con, "SELECT * FROM `category`") or die('query failed');
         if(mysqli_num_rows($select_categorys) > 0){
            while($fetch_categorys = mysqli_fetch_assoc($select_categorys)){
      ?>
      <div class="box">
         <div class="details">category:<?php echo $fetch_categorys['category_ID']; ?></div>
         <div class="name"><?php echo $fetch_categorys['category_name']; ?></div>
         <a href="admin_update_category.php?update=<?php echo $fetch_categorys['category_ID']; ?>" class="option-btn">update</a>
         <a href="admin_category.php?delete=<?php echo $fetch_categorys['category_ID']; ?>" class="delete-btn" onclick="return confirm('delete this category?');">delete</a>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">no category added yet!</p>';
      }
      ?>
   </div>
   

</section>












<script src="js/admin_script.js"></script>

</body>
</html>