<?php

@include 'config.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:login.php');
};

if(isset($_POST['update_category'])){

   $update_p_id = $_POST['update_p_id'];
   $name = mysqli_real_escape_string($con, $_POST['name']);

   mysqli_query($con, "UPDATE `category` SET category_name = '$name' WHERE category_ID = '$update_p_id'") or die('query failed');

   $message[] = 'category updated successfully!';

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>update category</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/admin_style.css">

</head>
<body>
   
<?php @include 'admin_header.php'; ?>

<section class="update-category">

<?php

   $update_id = $_GET['update'];
   $select_products = mysqli_query($con, "SELECT * FROM `category` WHERE category_ID = '$update_id'") or die('query failed');
   if(mysqli_num_rows($select_products) > 0){
      while($fetch_products = mysqli_fetch_assoc($select_products)){
?>

<form action="" method="post" enctype="multipart/form-data">
   <input type="hidden" value="<?php echo $fetch_products['category_ID']; ?>" name="update_p_id">
   <input type="text" class="box" value="<?php echo $fetch_products['category_name']; ?>" required placeholder="update category name" name="name">
   <input type="submit" value="update category" name="update_category" class="btn">
   <a href="admin_category.php" class="option-btn">go back</a>
</form>

<?php
      }
   }else{
      echo '<p class="empty">no update product select</p>';
   }
?>

</section>













<script src="js/admin_script.js"></script>

</body>
</html>